@extends('layouts.app')
@section('content')
<div class="container">
	@if (session('status'))
        <div class="alert alert-success">
            {{ session('status') }}
        </div>
    @endif
	<div class="pull-left" style="margin-right: 48%;">
		<button class="btn btn-primary add-modal">Add More</button>
	</div>
	<div class="pull-right" style="width: 30%">
		<input type="text" class="form-control" name="search" id="search" placeholder="Search">
	</div>
	<table class="table" id="peopletable">
		<thead class="thead-dark">
			<tr>
				<th>Name</th>
				<th>Email</th>
				<th>Contact</th>
				<th>Action</th>
			</tr>
		</thead>
	</table>
</div>
 <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog modal-lg">
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title modal-header"></h4>
        </div>
        <div class="modal-body">
		    <form class="form-horizontal" role="form" >

		      <input id="id" type="hidden" readonly class="form-control fid" name="id">

		      <div class="form-group">
		        <label for="name" class="col-md-4 control-label">Name</label>

		        <div class="col-md-6">
		            <input id="name" type="name" class="form-control name" name="name">
		        </div>
		      </div>
		      
		      <div class="form-group">
		        <label for="email" class="col-md-4 control-label">Email Address</label>

		        <div class="col-md-6">
		            <input id="email" type="email" class="form-control email" name="email">
		        </div>
		      </div>

		      <div class="form-group">
		        <label for="contact" class="col-md-4 control-label">Contact</label>

		        <div class="col-md-6">
		            <input id="contact" type="contact" class="form-control contact" name="contact">
		        </div>
		      </div>

		      <div class="form-group password-field">
		        <label for="password" class="col-md-4 control-label">Password</label>

		        <div class="col-md-6">
		            <input id="password" type="password" class="form-control password" name="password">
		        </div>
		      </div>

		      <div class="form-group">
		        <div class="col-md-8 col-md-offset-4">
		            <button class="btn btn-primary action_btn" data-dismiss="modal" ></button>
		        </div>
		      </div>
       		</form>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>
  
<script>
$(function() {
	$.ajaxSetup({
	headers: {
	'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
	}
	});
	$('#peopletable').DataTable({
		processing: true,
		serverSide: true,
		ajax: '{!! route('peoplesdata') !!}',
		columns: [
		{ data: 'name', name: 'name' },
		{ data: 'email', name: 'email' },
		{ data: 'contact', name: 'contact' },
		{ data: 'action', name: 'action', orderable: false, searchable: false }
		]
	});


	//------------------------------------
	//Using Controller via search route..
	//------------------------------------
	// $('#search').on('keyup',function(){
	// 	$value = $(this).val();	
	// 	$.ajax({		
	// 	type : 'POST',		
	// 	url : '{{url('search')}}',		
	// 	data:{'search':$value},		
	// 	success:function(data){		
	// 	$('tbody').html(data);		
	// 	}		
	// 	});
	// });

	//----------------------------------
	//Using DataTable search function...
	//----------------------------------
	$('#search').on('keyup',function(){
		$('.table').DataTable().search($(this).val()).draw();
	});

	//--------------------------
	//deletion in datatable..
	//--------------------------
	$(document).on('click', '.delete', function() {
		var id = $(this).data('id');
		var token = $(this).data("token");
		$.ajax({
		type: 'PUT',
		url: "/deletedata/"+id,
		data: {
			'id': id,
			'_method': 'DELETE',
			'_token': token,
		},
		success: function(data) {
		  $('.table').DataTable().draw(false);
		}
		});
	});

	//----------------------
	//show edit model...
	//----------------------
	$(document).on('click','.edit-model', function(){
		$('.action_btn').text('Update');
		$('.action_btn').removeClass('add');
		$('.action_btn').addClass('update');
		$('.modal-header').text('Update Info');
		$('.password-field').hide();
		$('.name').val($(this).data('name'));
        $('.email').val($(this).data('email'));
        $('.contact').val($(this).data('contact'));
        $('.fid').val($(this).data('id'));
		$('.form-horizontal').show();
		$('#myModal').modal('show');
	});

	//-------------------------
	//Update data table...
	//-------------------------
	$(document).on('click','.update', function(e) {	
		e.preventDefault();
		$.ajax({
			type: 'POST',
			url: 'editdata',
			data: {

				'id': $("#id").val(),
				'name': $("#name").val(),
				'email': $("#email").val(),
				'contact': $("#contact").val()
			},
			success:function(data){
				$('.table').DataTable().draw(false);

			}
		});
	});

	//-------------------------
	//show add model...
	//-------------------------
	$(document).on('click','.add-modal', function(){
		$('.action_btn').text('Submit');
		$('.action_btn').removeClass('update');
		$('.action_btn').addClass('add');
		$('.password-field').show(); 
		$('.modal-header').text('Add More People');
		$('.name').val('');
        $('.email').val('');
        $('.contact').val('');
        $('.fid').val('');
		$('.form-horizontal').show();
		$('#myModal').modal('show');
	});

	//---------------------------
	//adding data to datatable...
	//---------------------------
	$(document).on('click', '.add', function(e){
		e.preventDefault();
		$.ajax({
			type: 'POST',
			url: '{{url('addpeople')}}',
			data: {
				'name': $('.name').val(),
				'email': $('.email').val(),
				'contact': $('.contact').val(),
				'password': $('.password').val()
			},
			success:function(data){
				$('.table').DataTable().draw(false);
			}
		});
	});
});

</script>
@endsection