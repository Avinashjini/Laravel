$(function() {
	$.ajaxSetup({
	headers: {
	'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
	}
	});
	$('#peopletable').DataTable({
		processing: true,
		serverSide: true,
		ajax: '{!! route('peoplesdata') !!}',
		columns: [
		{ data: 'name', name: 'name' },
		{ data: 'email', name: 'email' },
		{ data: 'contact', name: 'contact' },
		{ data: 'action', name: 'action', orderable: false, searchable: false }
		]
	});


	/*
	//
	//Using Controller via search route..
	//
	*/

	// $('#search').on('keyup',function(){
	// 	$value = $(this).val();	
	// 	$.ajax({		
	// 	type : 'POST',		
	// 	url : '{{url('search')}}',		
	// 	data:{'search':$value},		
	// 	success:function(data){		
	// 	$('tbody').html(data);		
	// 	}		
	// 	});
	// });

	/*
	//
	//Using DataTable search function...
	//
	*/
	$('#search').on('keyup',function(){
		$('.table').DataTable().search($(this).val()).draw();
	});

	/*
	//
	//deletion in datatable..
	//
	*/
	$(document).on('click', '.delete', function() {
		var id = $(this).data('id');
		var token = $(this).data("token");
		$.ajax({
		type: 'PUT',
		url: "/deletedata/"+id,
		data: {
			'id': id,
			'_method': 'DELETE',
			'_token': token,
		},
		success: function(data) {
		  $('.table').DataTable().draw(false);
		}
		});
	});

	/*
	//
	//show edit model...
	//
	*/
	$(document).on('click','.edit-model', function(){
		$('.action_btn').text('Update');
		$('.action_btn').removeClass('add');
		$('.action_btn').addClass('update');
		$('.modal-header').text('Update Info');
		$('.password-field').hide();
		$('.name').val($(this).data('name'));
        $('.email').val($(this).data('email'));
        $('.contact').val($(this).data('contact'));
        $('.fid').val($(this).data('id'));
		$('.form-horizontal').show();
		$('#myModal').modal('show');
	});

	/*
	//
	//Update data table...
	//
	*/
	$(document).on('click','.update', function(e) {	
		e.preventDefault();
		$.ajax({
			type: 'POST',
			url: 'editdata',
			data: {

				'id': $("#id").val(),
				'name': $("#name").val(),
				'email': $("#email").val(),
				'contact': $("#contact").val()
			},
			success:function(data){
				$('.table').DataTable().draw(false);

			}
		});
	});

	$(document).on('click','.add-modal', function(){
		$('.action_btn').text('Submit');
		$('.action_btn').removeClass('update');
		$('.action_btn').addClass('add');
		$('.password-field').show(); 
		$('.modal-header').text('Add More People');
		$('.name').val('');
        $('.email').val('');
        $('.contact').val('');
        $('.fid').val('');
		$('.form-horizontal').show();
		$('#myModal').modal('show');
	});

	$(document).on('click', '.add', function(e){
		e.preventDefault();
		$.ajax({
			type: 'POST',
			url: '{{url('addpeople')}}',
			data: {
				'name': $('.name').val(),
				'email': $('.email').val(),
				'contact': $('.contact').val(),
				'password': $('.password').val()
			},
			success:function(data){
				$('.table').DataTable().draw(false);
			}
		});
	});
});
