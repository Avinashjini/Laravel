<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');

Route::get('/user/verify/{token}', 'Auth\RegisterController@verifyUser');

Route::get('addPayment','PaypalController@addPayment')->name('addPayment');

//-------------------------
// route for post request
//-------------------------
Route::post('paypal', 'PaypalController@postPaymentWithpaypal')->name('paypal');

//---------------------------------
// route for check status responce
//---------------------------------
Route::get('paypal','PaypalController@getPaymentStatus')->name('status');

//---------------------------------
// route for CRUD in datatable
//---------------------------------
Route::get('/people','PeopleController@show')->name('people');
Route::get('/peoplesdata','PeopleController@index')->name('peoplesdata');
Route::post('/addpeople','PeopleController@store')->name('addpeople');
Route::post('/editdata','PeopleController@update')->name('editdata');
Route::put('/deletedata/{id}','PeopleController@destroy')->name('delete');

//---------------------------------
// route for custom search in datatable
//---------------------------------
Route::post('/search', 'PeopleController@searchquery')->name('search');